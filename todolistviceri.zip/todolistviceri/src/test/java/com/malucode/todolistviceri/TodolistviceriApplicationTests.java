package com.malucode.todolistviceri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodolistviceriApplicationTests {

	@Test
	void contextLoads() {
	}

}
